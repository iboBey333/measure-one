%TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*%
%TF.CreationDate,2026-08-28T22:43:42+03:00*%
%TF.ProjectId,Measure_One_Slider_Pointer_A,4d656173-7572-4655-9f4f-6e655f536c69,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-28 22:43:42*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
