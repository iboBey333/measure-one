%MOIN*%
%OFA0B0*%
%FSLAX46Y46*%
%IPPOS*%
%LPD*%
G01*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:31:02+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_B,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:31:02*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:31:55+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_C,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:31:55*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:32:35+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_D,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:32:35*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:33:11+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_E,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:33:11*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:33:48+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_F,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:33:48*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:34:21+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_G,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:34:21*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:35:00+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_H,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:35:00*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*