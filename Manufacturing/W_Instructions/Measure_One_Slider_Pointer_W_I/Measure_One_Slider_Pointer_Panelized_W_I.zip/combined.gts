%MOIN*%
%OFA0B0*%
%FSLAX46Y46*%
%IPPOS*%
%LPD*%
G01*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:44:06+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_Pointer_B,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:44:06*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:44:43+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_Pointer_C,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:44:43*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:45:57+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_Pointer_D,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:45:57*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:46:32+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_Pointer_E,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:46:32*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:46:56+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_Pointer_F,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:46:56*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:47:41+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_Pointer_G,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:47:41*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T18:48:15+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_Pointer_H,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 18:48:15*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*