%MOIN*%
%OFA0B0*%
%FSLAX46Y46*%
%IPPOS*%
%LPD*%
G01*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T01:05:38+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_B,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 01:05:38*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T01:11:06+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_C,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 01:11:06*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T01:10:01+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_D,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 01:10:01*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T01:12:28+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_E,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 01:12:28*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T01:14:26+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_F,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 01:14:26*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T01:15:10+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_G,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 01:15:10*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T01:16:05+03:00*
G04 #@! TF.ProjectId,Measure_One_Slider_H,4d656173-7572-4655-9f4f-6e655f536c69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 01:16:05*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*