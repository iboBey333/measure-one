%MOIN*%
%OFA0B0*%
%FSLAX46Y46*%
%IPPOS*%
%LPD*%
G01*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T01:03:27+03:00*
G04 #@! TF.ProjectId,Measure_One_Main_Body_B,4d656173-7572-4655-9f4f-6e655f4d6169,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 01:03:27*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T00:55:13+03:00*
G04 #@! TF.ProjectId,Measure_One_Main_Body_C,4d656173-7572-4655-9f4f-6e655f4d6169,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 00:55:13*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T00:54:09+03:00*
G04 #@! TF.ProjectId,Measure_One_Main_Body_D,4d656173-7572-4655-9f4f-6e655f4d6169,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 00:54:09*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T00:52:59+03:00*
G04 #@! TF.ProjectId,Measure_One_Main_Body_E,4d656173-7572-4655-9f4f-6e655f4d6169,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 00:52:59*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T00:48:44+03:00*
G04 #@! TF.ProjectId,Measure_One_Main_Body_F,4d656173-7572-4655-9f4f-6e655f4d6169,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 00:48:44*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
G04 next file*
G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-08-25T00:50:50+03:00*
G04 #@! TF.ProjectId,Measure_One_Main_Body_G,4d656173-7572-4655-9f4f-6e655f4d6169,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-08-25 00:50:50*
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*